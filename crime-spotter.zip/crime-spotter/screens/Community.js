import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import StackNavigator from '../components/AppStackNavigator'

export default class Community extends React.Component{
  render(){
    return(
      <View>
      <Text>We will add community here.</Text>
      </View>
    )
  }
}