import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import AppHeader from '../components/AppHeader';

let customFonts = {
  'Patrick-Hand': require('../assets/PatrickHand-Regular.ttf'),
};
export default class Homescreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fontsLoaded: false,
    };
  }

  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }

  componentDidMount() {
    this._loadFontsAsync();
  }
  render() {
    if (!this.state.fontsLoaded) {
      return <AppLoading />;
    } else {
      return (
        <SafeAreaProvider>
          <View style={styles.container}>
            <View style={styles.appTitleContainer}>
              <AppHeader />

              <Image
                source={{
                  uri: 'https://thumbs.gfycat.com/DelayedVacantDassie.webp',
                }}
                style={styles.appLogo}
              />
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.button1}
                onPress={() => {
                  this.props.navigation.navigate('Emergency_Services');
                }}>
                <Image
                  source={require('../assets/alarm.png')}
                  style={styles.buttonLogo1}
                />
                <Text style={styles.textB}>Emergency Services</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.button2}
                onPress={() => {
                  this.props.navigation.navigate('Report');
                }}>
                <Image
                  source={require('../assets/camera.png')}
                  style={styles.buttonLogo2}
                />
                <Text style={styles.textB}>Report Hazard</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.button1}
                onPress={() => {
                  this.props.navigation.navigate('On_Map');
                }}>
                <Image
                  source={require('../assets/map.png')}
                  style={styles.buttonLogo1}
                />
                <Text style={styles.textB}>See On Map</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.button2}
                onPress={() => {
                  this.props.navigation.navigate('Community');
                }}>
                <Image
                  source={require('../assets/team.png')}
                  style={styles.buttonLogo2}
                />
                <Text style={styles.textB}>Community</Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaProvider>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  appLogo: {
    width: 90,
    height: 90,
    alignSelf: 'center',
    // marginTop: '8%',
  },
  appTitleContainer: {
    flex: 0.5,
  },

  buttonContainer: {
    flex: 0.6,
    backgroundColor: '#C5C6D0',
    flexDirection: 'row',
    //justifyContent: 'space-around',
  },
  button1: {
    width: 150,
    height: 120,
    backgroundColor: 'white',
    borderWidth: 0.01,
    borderRadius: 6,
    borderColor: 'gray',
    //marginTop: '4%',
    justifyContent: 'center',
  },
  button2: {
    width: 150,
    height: 120,
    backgroundColor: 'white',
    borderWidth: 0.01,
    borderRadius: 6,
    borderColor: 'gray',
    // marginTop: '4%',
    justifyContent: 'center',
    marginLeft:'23%'
  },
  textB: {
    textAlign: 'center',
    //fontFamily: 'Patrick-Hand',
    //fontSize: '18px',
  },
  buttonLogo1: {
    width: 60,
    height: 80,
    alignSelf: 'center',
  },
  buttonLogo2: {
    width: 80,
    height: 80,
    alignSelf: 'center',
  },
});
