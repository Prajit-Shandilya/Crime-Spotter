import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import Homescreen from '../screens/Homescreen';
import Emergency from '../screens/Emergency';
import Community from '../screens/Community';
import Onmap from '../screens/Onmap';
import Report from '../screens/Report';
import { NavigationContainer } from '@react-navigation/native';

const Stack = createStackNavigator();
const StackNavigator = () => {
  return (
    
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        //headerShown: false
      }}
    >
      <Stack.Screen name="Home" component={Homescreen} />
      <Stack.Screen name="Emergency_Services" component={Emergency} />
      <Stack.Screen name="Community" component={Community} />
     <Stack.Screen name="Report" component={Report} />
     <Stack.Screen name="On_Map" component={Onmap} />
      
    </Stack.Navigator>
    
  );
};

export default StackNavigator;